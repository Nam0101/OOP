
public class TestPassingParameter{
    public static void main(String[] args){
        DigitalVideoDisc jungLeDVD= new DigitalVideoDisc("Jungle");
        DigitalVideoDisc cinderellaDVD = new DigitalVideoDisc("Cinderella");
//        DVDWrapper wD1= new DVDWrapper(jungLeDVD);
//        DVDWrapper wD2= new DVDWrapper(cinderellaDVD);
        System.out.println("jungle dvd title: "+jungLeDVD.getTitle());
        System.out.println("Cinderella dvd title: "+cinderellaDVD.getTitle());
        swap(jungLeDVD,cinderellaDVD);
        System.out.println("After swap");
        System.out.println("jungle dvd title: "+jungLeDVD.getTitle());
        System.out.println("Cinderella dvd title: "+cinderellaDVD.getTitle());
        System.out.println("Number DVD:"+Integer.toString(cinderellaDVD.getNBDigitalVideoDiscs()));
        changeTitle(jungLeDVD,cinderellaDVD.getTitle());
        System.out.println("jungle dvd title: "+jungLeDVD.getTitle());
    }
    public static void changeTitle(DigitalVideoDisc dvd,String title){
    	String oldTitle = dvd.getTitle();
        dvd.setTitle(title);
        dvd  = new DigitalVideoDisc(oldTitle);
    }
//    public static void swap(DVDWrapper dvd1,DVDWrapper dvd2){
//    	DigitalVideoDisc temp=dvd1.innerObject;
//        dvd1.innerObject= dvd2.innerObject;
//        dvd2.innerObject= temp;
//    }
    public static void swap(DigitalVideoDisc dvd1,DigitalVideoDisc dvd2) {
    	String dvd1Title = dvd1.getTitle();
    	String dvd2Title = dvd2.getTitle();
    	dvd1.setTitle(dvd2Title);
    	dvd2.setTitle(dvd1Title);
    	dvd1 = new DigitalVideoDisc(dvd1Title);
    	dvd2 = new DigitalVideoDisc(dvd2Title);
    }
    static class DVDWrapper{
    	public DigitalVideoDisc innerObject;
    	public DVDWrapper(DigitalVideoDisc innerObject) {
    		this.innerObject=innerObject;
    	}
    }
  
    
}
