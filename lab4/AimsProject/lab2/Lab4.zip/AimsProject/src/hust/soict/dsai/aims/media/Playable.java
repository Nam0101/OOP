package hust.soict.dsai.aims.media;

public interface Playable {
    public void play();
}
